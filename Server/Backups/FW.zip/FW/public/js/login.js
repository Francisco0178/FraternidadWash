$(document).ready(function(){
  var logError = $(".login .error");
  var regError = $(".register .error")

  $(".back").fadeIn(800).delay(100).queue(function(){
    $(this).css({'filter': 'blur(1px)'}).delay(50).queue(function () {
      $(this).css({'filter': 'blur(2px)'}).delay(50).queue(function () {
        $(this).css({'filter': 'blur(6px)'});
      });
    });
  });

  $(".goToReg").click(function(){
    $(".login").hide(256,function(){
      logError.fadeOut(300);
      $(".register").show(256);
    });
  });

  $(".goToLog").click(function(){
    $(".register").hide(256,function(){
      regError.fadeIn(300);
      $(".login").show(256);
    });
  });

  $(".loginBtn").click(function(){
    var email = $("#logEmail").val().toLowerCase();
    var pass = $("#logPass").val();
    post({ email: email, pass: pass},"/login",function(res){
      if(res == true){
        $.cookie("email", email);
        $.cookie("pass",  pass);
        window.location.href = "/user/"+email.split("@")[0];
      }
      else{
        logError.html(res).fadeIn(300);
      }
    })
  });

  $(".regBtn").click(function(){
    post({ email: $("#regEmail").val(), pass: $("#regPass").val(),pass1: $("#regPass1").val()},"/register",function(res){
      if(res.length == 4){
        $.cookie("email", res[2]);
        $.cookie("pass",  res[3]);
        window.location.href = "/user/"+res[0].toLowerCase()+"."+res[1].toLowerCase();
      }
      else{
        regError.html(res).fadeIn(300);
      }
    })
  });
});

function post(data,url,callback){
  $.ajax({
  url: url,
  type: 'POST',
  contentType: 'application/json',
  data: JSON.stringify(data)})
  .done(function( res ) {
    callback(res);
  });
}
